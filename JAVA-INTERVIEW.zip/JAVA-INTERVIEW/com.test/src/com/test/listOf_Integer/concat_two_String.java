package com.test.listOf_Integer;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class concat_two_String {

	public static void main(String[] args) {

	List<String> list1=Arrays.asList("java","spring");
	List<String> list2=Arrays.asList("hibernate","kafka");
	
	Stream<String> concatString=Stream.concat(list1.stream(),list2.stream());
	concatString.forEach(n->System.out.print(n + " "));
	}

}
