package com.test.listOf_Integer;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class list_Of_evenNumber {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(10,15,8,49,25,98,32);
		
		//To find even odd Number
	     //list.stream().filter(n->n%2==0).forEach(System.out::println);
	     //Odd number
	     //list.stream().filter(n->n%2!=0).forEach(System.out::println);
		
		//list.stream().map(s -> s + "").filter(s->s.startsWith("1")).forEach(System.out::println);
		
		//Find Duplicate
		/*List<Integer> myList = Arrays.asList(10,15,8,49,25,98,98,32,15);
        Set<Integer> set = new HashSet();        
        myList.stream().filter(n->!set.add(n)).forEach(System.out::println);*/
		
        List<Integer> myList = Arrays.asList(10,15,8,49,25,98,98,32,15);
        // myList.stream().findFirst().ifPresent(System.out::println);     
       //  myList.stream().findAny().ifPresent(System.out::println);
        
        /*long  count=myList.stream().count();
        System.out.println(count);*/
        
       /* Integer max=myList.stream().max(Integer::compare).get();        
        System.out.println(max);       
        
        Integer max1=myList.stream().max(Comparator.comparing(Integer::valueOf)).get();
        System.out.println(max1);
        */
        
        //sorted
       // myList.stream().sorted().forEach(System.out::println);
       
        //sort list in descending order
        
        myList.stream().sorted(Collections.reverseOrder()).forEach(System.out::println);
        
        
        List<Integer> integerList = Arrays.asList(4,5,6,7,1,2,3);
    
         
        integerList.stream().map(n->n*n*n).forEach(n->System.out.print(n+" "));
        
        System.out.println("\n---------------------------------");
        
        integerList.stream().map(i->i*i*i).filter(n->n>50)
          .forEach(n->System.out.print(n+" "));
        
        System.out.println("\n=================================");
        integerList.stream().map(i->i*i*i).filter(n->n>100).forEach(System.out::println);
		   
		
		
		
		
		
	      
	      


	}

}
