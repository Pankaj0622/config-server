package com.test;

import java.util.List;
import java.util.stream.Collectors;

public class Lab3 {

	public static void main(String[] args) {

		List<String> strings=List.of("Bostan","India");
		
		List<String> stringResult=strings.stream().filter(s->s.equals("Bostan")).collect(Collectors.toList());
		
		System.out.println(stringResult);
	}

}
