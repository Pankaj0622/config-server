package com.String.Program;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class tes1 {

	public static void main(String[] args) {
		
		        List<Integer> myList = new ArrayList<>(Arrays.asList(1,2,3,4,5,6,7,8,9));

		        // Indices to remove (for example, removing elements at indices 1 and 3)
		        List<Integer> indicesToRemove = Arrays.asList(2, 4);

		        // Create a sublist based on indices
		        List<Integer> sublistToRemove = new ArrayList<>(myList.subList(indicesToRemove.get(0), indicesToRemove.get(1) + 1));

		        // Remove the sublist from the original list
		        myList.removeAll(sublistToRemove);

		        // Print the modified list
		        System.out.println("Modified List: " + myList);
		    }
		}


	