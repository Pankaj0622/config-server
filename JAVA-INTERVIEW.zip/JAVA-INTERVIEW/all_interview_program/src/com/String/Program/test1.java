package com.String.Program;

public class test1 {

	public static void main(String[] args) {
    /*  String str=null;
      System.out.println(str.valueOf(10));*/
		
		String str="abc";
		StringBuffer st2=new StringBuffer(str);
		System.out.println(str.equals(st2));

	}

}
