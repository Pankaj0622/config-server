package com.List_Integer;

import java.util.Arrays;
import java.util.List;

public class startsWith_number_1 {

	public static void main(String[] args) {
        List<Integer> myList = Arrays.asList(10,15,8,49,25,98,32);
        myList.stream().map(s->s+"") //convert integer to String
             .filter(s->s.startsWith("1")).forEach(System.out::println);

	}

}
