package com.List_Integer;

import java.util.Arrays;
import java.util.List;

public class find_firstElement_arrayList {

	public static void main(String[] args) {
        List<Integer> myList = Arrays.asList(10,15,8,49,25,98);
        
        Integer  firstNumber=myList.stream().findFirst().get();
        System.out.println(firstNumber);
       
       
       Integer lastNumber = myList.stream().reduce((x,y) -> y).get();
       System.out.println(lastNumber);
        

	}

}
