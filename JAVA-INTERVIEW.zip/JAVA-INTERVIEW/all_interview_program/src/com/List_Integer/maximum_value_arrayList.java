package com.List_Integer;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class maximum_value_arrayList {

	public static void main(String[] args) {
        List<Integer> myList = Arrays.asList(10,15,8,49,25,98,98,32,15);
        
        int max=myList.stream().max(Integer::compare).get();
        System.out.println(max);
        
        int maxNumber=myList.stream().max(Comparator.comparing(Integer::valueOf)).get();
        System.out.println(maxNumber);

	}

}
