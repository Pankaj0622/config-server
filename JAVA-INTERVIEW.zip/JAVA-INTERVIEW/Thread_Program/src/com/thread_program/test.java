package com.thread_program;

public class test {

	public static void main(String[] args) {
		String str="string";
		str.concat("new String");
		System.out.println(str);

	}

}
