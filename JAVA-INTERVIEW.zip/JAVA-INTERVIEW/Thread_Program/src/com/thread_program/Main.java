package com.thread_program;


class NumberPrinter implements Runnable {
    private int start;
    private int end;

    public NumberPrinter(int start, int end) {
        this.start = start;
        this.end = end;
    }

    @Override
    public void run() {
        for (int i = start; i <= end; i++) {
            System.out.println(i);
        }
    }
}

public class Main {

	public static void main(String[] args) {
		int start = 1;
        int end = 10;

        // Create a thread and start it
        Thread thread = new Thread(new NumberPrinter(start, end));
        thread.start();
    }
}
