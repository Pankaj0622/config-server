package com.math.lab;



public class test {
	
   
	public static void main(String[] args) {
		
		 int x=2*+2-21/-42+-53;
		 System.out.println(x);
     
	}

}
