package com.math.lab;

import java.util.Scanner;

public class leap_year {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a year");
		int year=sc.nextInt();
		if(year%4==0)
			System.out.println("Year "+year+" is a leap year");
		else
			System.out.println("Year "+year +"is not a leap year");

	}

}
