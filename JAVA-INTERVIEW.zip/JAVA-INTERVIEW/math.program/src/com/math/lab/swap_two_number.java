package com.math.lab;

import java.util.Scanner;

public class swap_two_number {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a and b value");
		int a=sc.nextInt();
		int b=sc.nextInt();
		System.out.println("Before swapping numbers\na="+a+"\nb="+b);
        /*a=a+b;
        b=a-b;
        a=a-b;*/
		a=a^b;
		b=a^b;
		a=a^b;
		System.out.println("After swapping numbers\na="+a+"\nb="+b);

	}

}
