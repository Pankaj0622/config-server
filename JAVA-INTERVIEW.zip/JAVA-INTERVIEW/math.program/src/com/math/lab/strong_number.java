package com.math.lab;
import java.util.Scanner;
public class strong_number {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number");
		int num=sc.nextInt();
		int sum=0;
		int temp=num;
		
		
		while(temp!=0) {
			int digit=temp%10;
			int fact=1;
			for(int i=1;i<=digit;i++)
				fact=fact*i;
			    sum=sum+fact;
			    temp=temp/10;
		}
		if(sum==num)
			System.out.println("Number is strong:"+num);
		else
			System.out.println("Number is not strong:"+num);
		}
		
}

