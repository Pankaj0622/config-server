package com.math.lab;

import java.util.Scanner;

public class palindrome_number {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=sc.nextInt();
		
		  int reverse = 0;
	      int  temp = num;
	     //loop to find reverse number
	      while (temp != 0)
	       {
	     	int rem = temp % 10;
	     	reverse = reverse * 10 + rem;
	     	temp /= 10;
	       };

	     // palindrome if num and reverse are equal
	     if (num == reverse)
	       System.out.println (num + " is Palindrome");
	     else
	       System.out.println (num + " is not Palindrome");
	}

}
