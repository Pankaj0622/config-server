package com.math.lab;

public class fibonacci_series_program {

	public static void main(String[] args) {
		int a=0;
		int b=1;
		System.out.print(a+" "+b+" ");
		//int c=a+b;
		for(int i=3;i<=10;i++) {
			int c=a+b;
			    a=b;
			    b=c;
		
		System.out.print(c+" ");

	}
	}
}
