package com.math.lab;

import java.util.Scanner;

public class prime_number {	
	
	static boolean isPrime(int num) {
         //boolean flag=true;		
         for (int i = 2; i <= num / 2; i++)
             if (num % i == 0)
                 return false;
   
         return true;
     }
	
	public static void main(String[] args) {
		/*Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Number");
		int num=sc.nextInt();
		boolean flag=true;
		
		for(int i=2;i<num;i++) {
			if(num%i==0) {
				flag=false;
				  break;
			}
		}
		if(flag)
			System.out.println("Number is Prime:"+num);
		else {
			System.out.println("Number is not Prime"+num);
		}
	}
	*/
		
	if (isPrime(11))
        System.out.println(" true");
    else
        System.out.println(" false");
    if (isPrime(4))
        System.out.println(" true");
    else
        System.out.println(" false");

}
	}
