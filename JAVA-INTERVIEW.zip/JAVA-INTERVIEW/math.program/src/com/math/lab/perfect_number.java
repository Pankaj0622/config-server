package com.math.lab;

import java.util.Scanner;

public class perfect_number {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a number");
		int num=sc.nextInt();
		int sum=0;	
		
		//using for loop
		/*for(int i=1;i<num;i++) {
			if(num%i==0)
				sum=sum+i;
		}
		if(sum==num)
			System.out.println("Number is perfect number:"+num);
		else
			System.out.println("Number is not perfect number:"+num);*/
		
		//using while loop
		int i=1;
		
		//while(i<num)
			 while(i <= num/2)	
		{
			if(num%i==0)
				sum=sum+i;
			
			i++;
		}
		if(sum==num)
			System.out.println("Number is perfect number:"+num);
		else
			System.out.println("Number is not perfect number:"+num);

	}

}
