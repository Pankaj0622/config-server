package com.math.lab;

import java.io.IOException;

public class To_check_Lower_uper_digit {

	public static void main(String[] args) throws IOException {
		System.out.println("Enter a character");
		char ch=(char)System.in.read();
		if(ch>=65 && ch<=90)
			System.out.println("Character is upper case:"+ch);
		
		else if(ch>=97 && ch<=122)
			System.out.println("Character is Lower Case:"+ch);
		else if(ch>=48 && ch<=57)
			System.out.println("Char is Digit:"+ch);
		else
			System.out.println("Character is special Character:"+ch);
	}

}
