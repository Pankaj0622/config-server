package com.emp.program;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Stream;

public class test {

	
	public static void main(String[] args) {
		int n=7;
		
		
		int sum =Stream.iterate(new int[] {0,1},x->new int [] {x[1],x[0]+x[1]})
				.limit(n)
				.map(x->x[0])
				.collect(toList())
				.stream()
				.distinct()
				.filter(i-> i*2==0)
				.mapToInt(i->i).sum();
		
		return sum;	
		
		
		
		Function<List<Integer>,Integer> function=x->x
				 .stream()
				 .map(i->i*2)
				 .mapToInt(i->i)
				 .distinct()
				 .sum();
		
	  Function<Integer,Integer> function2=x->x*10;
	  Function<Integer,Integer> function3=x->x*100;
	  int len =function.andThen(function2).andThen(function3).apply(Arrays.asList(1,2,2));
	  System.out.println(len);
  

	}

	

}
