package com.emp.program;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.Collectors;

public class Emp {
	private String name;
	private int age;
	
	public Emp(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}	
	@Override
	public String toString() {
		return "Emp [name=" + name + ", age=" + age + "]";
	}
	public static void main(String[] args) {
		List<Emp> emp=createEmpList();
		
		//Name with age		
		List<String> empFilterList=emp.stream().filter(e->e.getAge()>20).
				map(Emp::getName).collect(Collectors.toList());
		//empFilterList.forEach((name)->System.out.println(name));
		empFilterList.forEach(System.out::println);
		
		//count employee Age above 20
		List<Emp> emp1=createEmpList();
		long count=emp1.stream().filter(e->e.getAge()>20).count();
		System.out.println("Number of Employee with age 25:"+count);
		
		// starts with  name
		List<Emp> emp2=createEmpList();		
		Optional<Emp> e1=emp2.stream().filter(name->name.getName().equalsIgnoreCase("Pankaj")).findAny();
		if(e1.isPresent())
			System.out.println(e1.get());
		
		//To find maximum age of Employee
		List<Emp>  emp3=createEmpList();
		OptionalInt maxAge=emp3.stream().mapToInt(Emp::getAge).max();
		if(maxAge.isPresent())
			System.out.println("Maximum age of Employee:"+maxAge);
		
		//Sort Employee Based On Age		
		List<Emp> emp4=createEmpList();
		emp4.sort((x1,x2)->x1.getAge()-x2.getAge());
		emp4.forEach(System.out::println);
		
		List<Emp> emp5=createEmpList();
		List<String> empName=emp5.stream().map(Emp::getName).collect(Collectors.toList());
		String employeeNameStr=String.join(",",empName);
		System.out.println("Employee Are:"+employeeNameStr);
		
		//Group Employee Name:		
		List<Emp> emp6=createEmpList();
		Map<String,List<Emp>> map=emp6.stream().collect(Collectors.groupingBy(Emp::getName));
		map.forEach((name,empListTemp)->System.out.println("Name:"+name+"==>"+empListTemp));
		
		//find the employee name  in sorted order whose  salary is grater than 1000 in java 8 using stream api

		

        System.out.println("Employees with salary greater than 1000 in sorted order: " + sortedNames);		
		
        
	}
	
  public static List<Emp> createEmpList(){
	List<Emp>  empList=new ArrayList<>();
	
	Emp e1=new Emp("pankaj",28);
	Emp e2=new Emp("Marting",20);
	Emp e3=new Emp("Mary",31);
	Emp e4=new Emp("Stephan",18);
	Emp e5=new Emp("Gary",26);
	
	empList.add(e1);
	empList.add(e2);
	empList.add(e3);
	empList.add(e4);
	empList.add(e4);
	empList.add(e5);
	return empList;	
	}  
}
