package string_interview_program;

public class swap_string_based_on_index {

	public static void main(String[] args) {

		String str="pankaj kumar pandey";
		
		String[] strArray=str.split(" ");
		
		String temp=strArray[0];
		       strArray[0]=strArray[2];
		       strArray[2]=temp;
		       
		System.out.println(strArray[0]+" "+strArray[1]+" "+strArray[2]);       
		
	}

}
