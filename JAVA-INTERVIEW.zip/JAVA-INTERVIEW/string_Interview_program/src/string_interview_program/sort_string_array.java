package string_interview_program;

public class sort_string_array {

	public static void main(String[] args) {
    String names[]= {"Manish","Pankaj","Kofel","Ajay","Rahule"};
    
    for(int i=0;i<names.length;i++) {
    	String nm=names[i];
    	System.out.println(nm);
    }
    
    for(int i=0;i<names.length;i++) {
    	for(int j=i+1;j<names.length;j++) {
    		String t1=names[i];
    		String t2=names[j];
    		
    	int res=t1.compareTo(t2);
    	 if(res>0) {
    		 names[i]=t2;
    		 names[j]=t1;
    	 }
    	}
    }
    System.out.println("\n Names in sorted order");
    for(int i=0;i<names.length;i++) {
    	String nm=names[i];
    	System.out.println(nm);
    }
		
		
	}

}
