package string_interview_program;

public class swap_two_string {

	public static void main(String[] args) {
        String  a="Hello";
        String  b="World";
        
        // without temp variable
        
        /*a=a+b;
        b=a.substring(0,a.length()-b.length());
        a=a.substring(b.length());        
        System.out.println("Swapping String:a="+a+" and b="+b);        
        System.out.println("a="+a);
        System.out.println("b="+b);*/
        
        
        System.out.println("Using temp variable");
        String  temp=a;
                a=b;
                b=temp;
                 
		System.out.println("a="+a);
		System.out.println("b="+b);
	}

}
