package string_interview_program;

public class string_Rotation {

	public static void main(String[] args) {
		
		System.out.println("Is army rotation of myar");
	    if(isRotation("army", "myar")){
	      System.out.println("yes");
	    }else{
	       System.out.println("no");
	    }

	  }

public static boolean isRotation(String first, String second) {
    if (first.length() != second.length()) {
      return false;
    }

    String concatenated = first + first;

    if (concatenated.indexOf(second) != -1) {
      return true;
    }

    return false;
  }
}
