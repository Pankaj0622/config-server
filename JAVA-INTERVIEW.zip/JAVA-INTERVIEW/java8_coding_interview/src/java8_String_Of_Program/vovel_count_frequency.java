package java8_String_Of_Program;

import java.util.HashMap;
import java.util.Map;

public class vovel_count_frequency {

	public static void main(String[] args) {

        String inputString = "This is a sample string to count the occurrences of vowels";

        Map<Character, Long> vowelFrequencyMap = new HashMap<>();
        vowelFrequencyMap.put('a', 0L);
        vowelFrequencyMap.put('e', 0L);
        vowelFrequencyMap.put('i', 0L);
        vowelFrequencyMap.put('o', 0L);
        vowelFrequencyMap.put('u', 0L);

        inputString.chars()
                .mapToObj(c -> (char) c)
                //.map(Character::toLowerCase)
                .filter(c -> "aeiou".indexOf(c) != -1)
                .forEach(c -> vowelFrequencyMap.put(c, vowelFrequencyMap.get(c) + 1));

        System.out.println("Frequency of each vowel:");
        vowelFrequencyMap.forEach((vowel, frequency) -> System.out.println(vowel + ": " + frequency));
    }
}
