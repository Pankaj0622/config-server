package java8_String_Of_Program;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class starts_with_j_words {

	public static void main(String[] args) {
		List<String> names = Arrays.asList("Chris", "HTML", "XML", "CSS","H");
		
	    Stream<String> s = names.stream().filter(name -> name.startsWith("C"));

	    System.out.println(s.collect(Collectors.toList()));
	    
		//Which string equls to HTML will not print
	    List<String> result=names.stream().filter(x->!"HTML".equals(x)).collect(Collectors.toList());
	    
	    result.forEach(System.out::println);
	  }
	
	  
	}