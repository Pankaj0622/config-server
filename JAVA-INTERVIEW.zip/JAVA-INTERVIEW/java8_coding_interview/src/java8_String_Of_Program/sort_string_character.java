package java8_String_Of_Program;

import java.util.List;
import java.util.stream.Collectors;

public class sort_string_character {

	public static void main(String[] args) {
		String str = "welcome";
		//1 approach
        List<Character> sortedChars = str.chars()
                .mapToObj(c -> (char) c)
                .sorted()
                .collect(Collectors.toList());

        // Print the sorted characters
        for (Character ch : sortedChars) {
            System.out.print(ch);

	}
        
        //2 approach
        String sortedStr = sortedChars.stream()
                .map(String::valueOf)
                .collect(Collectors.joining());
        System.out.println(sortedStr);

}
}