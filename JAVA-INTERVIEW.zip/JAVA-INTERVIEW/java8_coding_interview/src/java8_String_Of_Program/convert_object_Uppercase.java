package java8_String_Of_Program;

import java.util.Arrays;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class convert_object_Uppercase {

	public static void main(String[] args) {
		List<String>  names=Arrays.asList("aa","bb","cc");
		List<String> namesList=names.stream().map(String::toUpperCase)
				.collect(Collectors.toList());
		System.out.println(namesList);
		
		
	//18. How to count each element/word from the String ArrayList in Java8?	
		
        List<String> myList = Arrays.asList("AA", "BB", "AA", "CC");
        
        Map<String,Long> nameList=myList.stream()
        		       .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
        
        System.out.println(nameList);

       // 19. How to find only duplicate elements with its count from the String ArrayList in Java8?  
        List<String> namList = Arrays.asList("AA", "BB", "AA", "CC","DD","DD");
        
        Map<String,Long> namesCount=namList.stream()
        		 .filter(x->Collections.frequency(namList,x)>1)
        		 .collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
        System.out.println(namesCount);

        
        

	}

}
