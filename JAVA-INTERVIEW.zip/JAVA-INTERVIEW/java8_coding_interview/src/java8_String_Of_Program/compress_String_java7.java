package java8_String_Of_Program;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class compress_String_java7 {

	public static void main(String[] args) {
		
		System.out.println(compress_String_java7.Comprimir("aaaabbbbbcccdddee"));

	


	}
public static String Comprimir(String input) {
	/*String output="";
	Map<Character,Integer> map=new HashMap<Character,Integer>();
	for(int i=0;i<input.length();i++) {
		Character character=input.charAt(i);
		if(map.containsKey(character)) {
				map.put(character,map.get(character)+1);
			}else
				map.put(character, 1);
		}
		for(Entry<Character,Integer> entry : map.entrySet()) {
			output +=entry.getValue()+""+entry.getKey().charValue();
		}
		return output;
		}*/
	
	  
	  
	
}