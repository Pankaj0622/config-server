package java8_String_Of_Program;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class ArrayListPermutations {

    public static void main(String[] args) {
        List<String> inputList = new ArrayList<>(List.of("abc","def","ghi"));
        List<List<String>> permutations = generatePermutations(inputList);

        // Print the permutations
        permutations.forEach(System.out::println);
    }

    public static <T> List<List<T>> generatePermutations(List<T> inputList) {
        return permute(inputList, 0)
                .collect(Collectors.toList());
    }

    private static <T> Stream<List<T>> permute(List<T> list, int start) {
        return IntStream.range(start, list.size())
                .boxed()
                .flatMap(i -> {
                    List<T> temp = new ArrayList<>(list);
                    java.util.Collections.swap(temp, i, start);
                    return Stream.concat(
                            Stream.of(temp),
                            permute(temp, start + 1)
                    );
                });
    }
}
