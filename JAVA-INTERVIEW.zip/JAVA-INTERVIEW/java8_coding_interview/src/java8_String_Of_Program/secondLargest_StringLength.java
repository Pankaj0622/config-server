package java8_String_Of_Program;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class secondLargest_StringLength {

	public static void main(String[] args) {
		List<String> strings = Arrays.asList("apple", "banana","kp");

		String secondLargestString = strings.stream()
		                .sorted(Comparator.comparingInt(String::length).reversed()) // Sort by string length in descending order
		                .skip(1) // Skip the largest length string
		                .findFirst() // Get the first element (the second largest length string)
		                .orElse(null); // Default value if not found

		        System.out.println("Second largest string: " + secondLargestString);
		    }
		}