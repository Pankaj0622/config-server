package java8_String_Of_Program;

import java.util.stream.Collectors;

public class uniqie_char_string {

	public static void main(String[] args) {
		String inputString = "pankaj";

        // Convert the string to a character stream, remove duplicates, and collect back to a string
        String uniqueCharacters = inputString.chars()
                .mapToObj(c -> (char) c)
                .distinct()
                .map(Object::toString)
                .collect(Collectors.joining());

        System.out.println("Unique characters in the string: " + uniqueCharacters);

	}

}
