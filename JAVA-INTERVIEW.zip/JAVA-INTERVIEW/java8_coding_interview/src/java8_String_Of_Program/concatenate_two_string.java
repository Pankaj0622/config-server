package java8_String_Of_Program;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class concatenate_two_string {

	public static void main(String[] args) {
		     List<String> list1 = Arrays.asList("Java", "spring","spring");
	         List<String> list2 = Arrays.asList("explained", "through", "programs");
	 
	         Stream<String> concatStream = Stream.concat(list1.stream(), list2.stream()).distinct();
	         
	        // Concatenated the list1 and list2 by converting them into Stream
	 
	        concatStream.forEach(System.out::println);
	         
		
	}

}
