package java8_String_Of_Program;

import java.util.Arrays;
import java.util.stream.Collectors;

public class compress_string {

	public static void main(String[] args) {
		/*String str="aabbbccddbb";		
		String result=str.chars()
				 .mapToObj(c->(char)c)
				 .collect(Collectors.groupingBy(c->c,Collectors.counting()))
				 .entrySet().stream()
				 .map(entry->entry.getKey()+String.valueOf(entry.getValue()))
				 .collect(Collectors.joining());
		System.out.println(result);	*/	
		
		//output a2b5c2d2
		
		String str="aabbbccddbb";
		String result=Arrays.stream(str.split("(?<=(.))(?!\\1)"))
			   .map(s->s.length()+Character.toString(s.charAt(0)))
			   .collect(Collectors.joining());
		System.out.println(result);
		
		//output 2a3b2c2d2b
		
	
	}

}
