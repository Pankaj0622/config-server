package java8_String_Of_Program;

public class findMaxLengthOfString {

	public static void main(String[] args) {

		String strArray[]= {"Bangalore","Pune","Delhi","Hydrabad"};
		
		String maxlengthString=strArray[0];
		
		for (String str: strArray) {
			
			if(str.length()> maxlengthString.length()){
				maxlengthString=str;
			}
			
		}
		System.out.println(maxlengthString+"\t"+maxlengthString.length());
	}

}
