package java8_String_Of_Program;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class string_Length_3 {

	public static void main(String[] args) {
		
		List<String> stringList = Arrays.asList("Hello","Interview","Questions","Answers","Ram","for");
		
		//To Count Strings whose length is greater than 3 in List?
		
        long count = stringList.stream().filter(str -> str.length() > 3).count();
        System.out.println("String count with greater than 3 digit : " + count);
        
        //To Print Strings whose length is greater than 3 in List.
        
        List<String> longStringsList = stringList.stream()
                .filter(s -> s.length() >=3)
                .collect(Collectors.toList());
        
        System.out.println("List of strings with length greater than 3: " + longStringsList);
        
        
        stringList.stream().filter(str -> str.length() > 3).forEach(System.out::println);
        
	}

}
