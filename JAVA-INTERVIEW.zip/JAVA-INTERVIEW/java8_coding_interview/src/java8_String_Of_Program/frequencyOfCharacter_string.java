package java8_String_Of_Program;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class frequencyOfCharacter_string {

	public static void main(String[] args) {
		
		String str="welcomeewl";
		Map<Character, Long> frequency =
	            str.chars()
	               .mapToObj(c -> (char)c)
	               .collect(Collectors.groupingBy(Function.identity(), 
	            		   Collectors.counting()));
		System.out.println(frequency);
	}

}
