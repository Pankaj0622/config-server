package java8_String_Of_Program;

import java.util.Map;
import java.util.stream.Collectors;

public class frequency_Of_DuplicateCharsJava8 {

	public static void main(String[] args) {
		// given input string
        String input = "JavaJavaEEkz";

        // convert string into stream
        //Aprocah 1
        /*Map < Character, Long > result = input
            .chars().mapToObj(c -> (char) c)
            .collect(Collectors.groupingBy(c -> c, Collectors.counting()));      
        result.forEach((k, v) -> {
            if (v > 1) {
                System.out.println(k + " : " + v);
            }
        });*/
        
        //Occurance of each Character
        //Aprocah 2
        Map<Character, Long> charOccurrences = input.chars()
                .mapToObj(c -> (char) c)
                .collect(Collectors.groupingBy(c -> c, Collectors.counting()));
        System.out.println(charOccurrences);
        //----------
        Map<Object, Object> duplicateCharsWithCount = charOccurrences.entrySet()
        	    .stream()
        	    .filter(e -> charOccurrences.get(e.getKey()) > 1)
        	    .collect(Collectors.toMap(p -> p.getKey(), p -> p.getValue()));

        	System.out.println(duplicateCharsWithCount);
        
    }

}
