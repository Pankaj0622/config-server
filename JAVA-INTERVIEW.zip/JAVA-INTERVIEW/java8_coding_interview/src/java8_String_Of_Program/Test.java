package java8_String_Of_Program;

import java.util.Map;
import java.util.stream.Collectors;

public class Test {

	public static void main(String[] args) {

		
		
		        String inputString = "HelloWorld";

		        System.out.println("Original String: " + inputString);

		        System.out.println("Characters at Even Indices:");
		        printCharactersWithIndex(inputString, true);

		        System.out.println("\nCharacters at Odd Indices:");
		        printCharactersWithIndex(inputString, false);
		    }

		    private static void printCharactersWithIndex(String str, boolean evenIndices) {
		        for (int i = evenIndices ? 0 : 1; i < str.length(); i += 2) {
		            System.out.println("Index " + i + ": " + str.charAt(i));
		        }
		        System.out.println();
		    }
		}
