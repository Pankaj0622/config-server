package java8_String_Of_Program;

import java.util.Arrays;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class count_of_each_character_String {

	public static void main(String[] args) {
		//String input= "string data to count each character";
		String input="pankaj";
		Map<Character, Long> characterCountMap = input
                .chars() // convert to IntStream
                .mapToObj(c -> (char) c) // map to Character object
                .filter(ch -> !Character.isWhitespace(ch))
                .collect(Collectors.groupingBy(ch -> ch, Collectors.counting())); 
 
        // print to the console
        System.out.println("1. Characters and its Count in Random-order :- \n");
        characterCountMap
        .entrySet()
        .forEach(System.out::println);
}
		
	}

