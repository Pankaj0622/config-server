package java8_String_Of_Program;

public class addition_String {
	@FunctionalInterface
	interface StringOperation {
		
	    String performOperation(String str1, String str2);
	}
	public static void main(String[] args) {
		// Lambda expression using custom functional interface
        StringOperation concatenateStrings = (str1, str2) -> str1 + str2;

        // Strings to concatenate
        String firstString = "Hello, ";
        String secondString = "world!";

        // Applying the lambda expression
        String result = concatenateStrings.performOperation(firstString, secondString);

        // Displaying the result
        System.out.println(result); // Output: Hello, world!
    }
}

