package java8_String_Of_Program;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class string_Length_4 {

	public static void main(String[] args) {
		List<String> stringList = Arrays.asList("apple", "banana", "orange", "grape", "kiwi","microservice");

        long count = stringList.stream()
                .filter(s -> s.length() >=6)
                .peek(System.out::println) // Print each string whose length is greater than 3
                .count();

        List<String> longStringsList = stringList.stream()
                .filter(s -> s.length() >=7)
                .collect(Collectors.toList());

        System.out.println("Count of strings with length greater than 6: " + count);
        System.out.println("List of strings with length greater than 6: " + longStringsList);
	}

}
