package java8_String_Of_Program;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class remove_duplicate_char_String {

	public static void main(String[] args) {
		String input = "pankaj";
		
		/*String output = Arrays.asList(input.split(""))
								.stream()
								.distinct()
								.collect(Collectors.joining());
		System.out.println("Original String : " + input);
		System.out.println("After removing the duplicates : " + output);
		*/
		List<String> output = Arrays.asList(input.split(""))
				.stream()
				.distinct()
				.collect(Collectors.toList());
         System.out.println("Original String : " + input);
         System.out.println("After removing the duplicates : " + output);
         
         
         String inputString = "hello world";

         // Convert the string to a character stream, remove duplicates, and collect back to a string
         String uniqueCharacters = inputString.chars()
                 .mapToObj(c -> (char) c)
                 .distinct()
                 .map(Object::toString)
                 .collect(Collectors.joining());

         System.out.println("Unique characters in the string: " + uniqueCharacters);
	}
	

}
