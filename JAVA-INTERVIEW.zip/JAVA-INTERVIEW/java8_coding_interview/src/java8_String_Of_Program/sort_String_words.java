package java8_String_Of_Program;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class sort_String_words {

	public static void main(String[] args) {
		String str = "dbcaf";		 
        str = Stream.of(str.split(""))
                    .sorted()
                    .collect(Collectors.joining());
 
        System.out.println(str);
		
	}

}
