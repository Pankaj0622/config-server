package java8_String_Of_Program;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class shortest_and_longest_strings_in_list_of_words {

	public static void main(String[] args) {
        List<String> words = Arrays.asList("apple", "banana", "cherryaf", "date", "fig");
        
        //MIN String
        Optional<String> shortest =words.stream().min((s1,s2)->s1.length()-s2.length());
        shortest.ifPresent(s -> System.out.println("Shortest: " + s));
        
        Optional<String> shortestString1 = words.stream().min(Comparator.comparing(String::length));
        System.out.println("Shortest string is: " + shortestString1.orElse(""));
        
        //LONG String
        Optional<String> longest = words.stream().max((s1, s2) -> s1.length() - s2.length());
        longest.ifPresent(s -> System.out.println("Longest: " + s));
        
        Optional<String> longestString = words.stream().max(Comparator.comparing(String::length));
        System.out.println("Longest string is: " + longestString.orElse(""));
        


	}

}
