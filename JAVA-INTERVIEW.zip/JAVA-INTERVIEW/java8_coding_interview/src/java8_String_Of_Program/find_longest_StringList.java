package java8_String_Of_Program;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class find_longest_StringList {

	public static void main(String[] args) {
		List<String> names = Arrays.asList("java","springboot","microservices","Hibernate","Python"); 
		// 1.1 print to console
        System.out.println("Original String List :- \n" + names);
 
 
        // 2. find Longest name using collect(Collectors.maxBy(Comparator.comparingInt(String::length)))
        String longestStr = names
                .stream()
                .collect(Collectors.maxBy(Comparator.comparingInt(String::length)))
                .get();
        System.out.println("\nLongest String is = " + longestStr);
        
     // 2.1 find length of Longest name using collect(Collectors.summarizingInt(String::length))
        int lengthofLongestStr = names
                .stream()
                .collect(Collectors.summarizingInt(String::length))
                .getMax();
        System.out.println("\nLength of Longest String is = " + lengthofLongestStr);

	}

}
