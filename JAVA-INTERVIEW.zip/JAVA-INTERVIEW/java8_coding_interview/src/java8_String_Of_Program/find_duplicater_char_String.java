package java8_String_Of_Program;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class find_duplicater_char_String {

	public static void main(String[] args) {
		String str = "pankajp";

		Map<Character, Long> charOccurrences = str.chars()
                .mapToObj(c -> (char) c)
                .collect(Collectors.groupingBy(c -> c, Collectors.counting()));

        /*charOccurrences.entrySet().stream()
                .filter(entry -> entry.getValue() >1)
                .forEach(entry -> System.out.println("Duplicate Character: " + entry.getKey()));*/
        
        List duplicateChars = charOccurrences.keySet()
        	    .stream()
        	    .filter(k -> charOccurrences.get(k) > 1)
        	    .collect(Collectors.toList());

        	System.out.println(duplicateChars); 
	
	}

}
