package java8_String_Of_Program;
import java.util.StringJoiner;

public class add_prefixe_suffix {

	public static void main(String[] args) {
	StringJoiner stringJoiner = new StringJoiner(",", "#", "#");
	      stringJoiner.add("Interview");
	      stringJoiner.add("Questions");
	      stringJoiner.add("Answers");
	System.out.println("String after adding # in suffix and prefix :");
	System.out.println(stringJoiner);
		    }
		}


