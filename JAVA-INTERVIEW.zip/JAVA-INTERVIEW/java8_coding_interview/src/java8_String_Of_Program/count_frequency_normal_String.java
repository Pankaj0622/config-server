package java8_String_Of_Program;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class count_frequency_normal_String {

	public static void main(String[] args) {
		String str = "Hi Hello Hi pankaj pankaj";
	    List<String> s = Arrays.asList(str.split(" "));
	    Map<String, Long> hm = 
	              s.stream().collect(Collectors.groupingBy(Function.identity(), 
	              Collectors.counting()));

	              hm.entrySet().forEach(entry -> {

	             System.out.println(entry.getKey() + " " + entry.getValue());
	              });

	}

}
