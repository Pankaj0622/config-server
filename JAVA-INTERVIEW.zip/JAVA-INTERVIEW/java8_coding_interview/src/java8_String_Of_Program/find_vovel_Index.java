package java8_String_Of_Program;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class find_vovel_Index {

	public static void main(String[] args) {
		String str = "summervacation";

       /* List<Integer> vowelPositions = IntStream.range(0, str.length())
                .filter(i -> "aeiou".contains(Character.toLowerCase(str.charAt(i)) + ""))
                .boxed()
                .collect(Collectors.toList());

        System.out.println("Vowel Positions: " + vowelPositions);*/
		 for(int i=0; i<str.length(); i++) {
		      if(str.charAt(i) == 'a'|| str.charAt(i) == 'e'|| 
		          str.charAt(i) == 'i' || str.charAt(i) == 'o' || 
		          str.charAt(i) == 'u')
		        
		        System.out.println("Given string contains " + 
		            str.charAt(i)+" at the index " + i);
		    }
	}

}
