package java8_String_Of_Program;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Sorting_List_of_Strings {

	public static void main(String[] args) {
		List<String> words = Arrays.asList("banana", "apple", "cherry", "date");

        List<String> sortedWords = words.stream()
            .sorted()
            .collect(Collectors.toList()); // Sorting with Java 8

        sortedWords.forEach(System.out::println);
        
       //Sorting Strings in reverse order
        
       List<String> sortedreverse=words.stream().sorted(Collections.reverseOrder())
    		   .collect(Collectors.toList());
       System.out.println(sortedreverse);
	}

}
