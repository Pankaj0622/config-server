package java8_String_Of_Program;

import java.util.stream.IntStream;

public class EvenOddIndexPrint {

	public static void main(String[] args) {
		String inputString = "HelloWorld";

        System.out.println("Original String: " + inputString);

        System.out.println("Characters at Even Indices:");
        printCharactersWithIndex(inputString, true);

        System.out.println("\nCharacters at Odd Indices:");
        printCharactersWithIndex(inputString, false);
    }

    private static void printCharactersWithIndex(String str, boolean evenIndices) {
        IntStream.range(evenIndices ? 0 : 1, str.length())
                .filter(i -> i % 2 == (evenIndices ? 0 : 1))
                .forEach(i -> System.out.println("Index " + i + ": " + str.charAt(i)));
        System.out.println();
    }
}