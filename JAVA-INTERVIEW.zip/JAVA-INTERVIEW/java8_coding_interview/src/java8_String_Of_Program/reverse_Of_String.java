package java8_String_Of_Program;

public class reverse_Of_String {

	public static void main(String[] args) {
		//String str = "Hello World";
		String str="pankaj";
		String reversed = str.chars()
		                  .mapToObj(c -> String.valueOf((char) c))
		                  .reduce((s1, s2) -> s2 + s1)
		                  .orElse("");
		System.out.println(reversed);

	}

}
