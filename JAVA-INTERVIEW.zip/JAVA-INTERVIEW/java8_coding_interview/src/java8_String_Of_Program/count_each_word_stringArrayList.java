package java8_String_Of_Program;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class count_each_word_stringArrayList {

	public static void main(String[] args) {
		List<String> names = Arrays.asList("AA", "BB", "AA", "CC");
        Map<String,Long> namesCount=names
                                .stream()
                                .collect(
                                 Collectors.groupingBy(
                                 Function.identity()
                                 ,Collectors.counting()
                                 ));
        System.out.println(namesCount);
              
        
        System.out.println("2 nd Approach ");
        List<String> list = Arrays.asList("B", "A", "A", "C", "B", "A");
        
        Map<String, Long> frequencyMap = list.stream()
                .collect(Collectors.groupingBy(Function.identity(),
                        Collectors.counting()));
 
        for (Map.Entry<String, Long> entry: frequencyMap.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
	}

}
