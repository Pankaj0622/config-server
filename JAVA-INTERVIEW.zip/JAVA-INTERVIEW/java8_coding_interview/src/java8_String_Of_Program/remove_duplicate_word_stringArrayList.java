package java8_String_Of_Program;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class remove_duplicate_word_stringArrayList {

	public static void main(String[] args) {
		List<String> names = Arrays.asList("AA", "BB", "AA", "CC");
		names.stream()
        .distinct()
        .collect(Collectors.toList())
        .forEach(System.out::print);
	}

}
