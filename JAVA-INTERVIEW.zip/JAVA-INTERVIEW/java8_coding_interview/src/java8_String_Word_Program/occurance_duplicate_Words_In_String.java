package java8_String_Word_Program;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;


public class occurance_duplicate_Words_In_String {
	
	public static void main(String[] args) {
		
		String sentence = "alex brian charles alex charles david eric david";
		
		List<String> wordsList = Arrays.stream(sentence.split(" ")).collect(Collectors.toList());
		
		Map<String, Integer> wordsMapWithCount = wordsList.stream()
		        .collect(Collectors.toMap(Function.identity(), word -> 1, Math::addExact));

		System.out.println(wordsMapWithCount);
		
		Map<String, Integer> dupWordsMapWithCount = wordsMapWithCount.entrySet()
			    .stream().filter(e -> e.getValue() > 1)
			    .collect(Collectors.toMap(Entry::getKey, Entry::getValue));

			System.out.println(dupWordsMapWithCount);
			
			
			
		
	}

}
