package java8_String_Word_Program;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class frequency__Words_in_String {

	public static void main(String[] args) {
		String sentence = "alex brian charles alex charles david eric david";
		
		List<String> wordsList = Arrays.stream(sentence.split(" ")).collect(Collectors.toList());

		Map<String, Integer> wordsMapWithCount = wordsList.stream()
		        .collect(Collectors.toMap(Function.identity(), word -> 1, Math::addExact));

		System.out.println(wordsMapWithCount);
		
		
		
	}

}
