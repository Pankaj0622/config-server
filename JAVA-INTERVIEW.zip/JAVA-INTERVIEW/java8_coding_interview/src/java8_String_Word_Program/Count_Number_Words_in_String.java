package java8_String_Word_Program;

import java.util.Arrays;
import java.util.stream.Stream;

public class Count_Number_Words_in_String {

	public static void main(String[] args) {
		
		String inputString = "Java is a programming language.";
        // Removing leading and trailing whitespaces
        inputString = inputString.trim();
        // Splitting the string into words
        String[] words = inputString.split("\\s+");
        // Counting the number of words
        int wordCount = words.length;
        System.out.println("Number of words: " + wordCount);
        
        //===========================================
        System.out.println("Using Java 8");
        
        Stream<String> stwords=Arrays.stream(inputString.split("\\s+"));
        long count=stwords.count();
       System.out.println("The num of words in string :"+count);
	}

}
