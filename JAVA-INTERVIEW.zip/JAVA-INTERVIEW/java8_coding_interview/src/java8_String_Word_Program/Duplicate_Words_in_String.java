package java8_String_Word_Program;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Duplicate_Words_in_String {

	public static void main(String[] args) {
		String sentence = "alex brian charles alex charles david eric david";
		
		List<String> wordsList = Arrays.stream(sentence.split(" ")).collect(Collectors.toList());
		Set<String> tempSet = new HashSet<>();

		List<String> duplicateWords = wordsList.stream()
		    .filter(w -> !tempSet.add(w))
		    .collect(Collectors.toList());

		System.out.println(duplicateWords); 
	}

}
