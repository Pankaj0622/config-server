package java8_String_Word_Program;

import java.util.Arrays;
import java.util.stream.Collectors;

public class remove_duplicate_Words_String {

	public static void main(String[] args) {
		String inputString = "Java is a programming language and Java is widely used in the software industry.";
		
		     String[] words = inputString.split("\\s+");

	        // Using Java 8 stream and distinct to remove duplicates
	        String result = Arrays.stream(words)
	                .distinct()
	                .collect(Collectors.joining(" "));
	        
	        System.out.println("String after removing duplicate words: " + result);

	}

}
