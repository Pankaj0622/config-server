package com.employee_Program;

import java.util.ArrayList;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;



public class Sort_Employee_Object {

	public static void main(String[] args) {
		
        List <Employee1> employees = new ArrayList <Employee1> ();
        employees.add(new Employee1(10, "Ramesh", 35, 400000));
        employees.add(new Employee1(20, "John", 29, 350000));
        employees.add(new Employee1(30, "Tom", 30, 450000));
        employees.add(new Employee1(40, "Pramod", 28, 500000));
        
       //sort employee based on salary in ascending order
        //1 . Approach
        List<Employee1> employeesSortedList1 = employees.stream()
                .sorted((o1, o2) -> (int)(o1.getSalary() - o2.getSalary())).collect(Collectors.toList());
                  employeesSortedList1.forEach(System.out::println);
      //2.Approach
          List<Employee1> employeesSortedList2 = employees.stream()
                .sorted(Comparator.comparingLong(Employee1::getSalary)).collect(Collectors.toList()); //ascending order
             employeesSortedList1.forEach(System.out::println);	
             
       System.out.println("====Sort By Name====");
       // sort employee based on name in ascending order 
       
        List<Employee1> empSortedByName = employees.stream()
                     .sorted((e1, e2) -> e1.getName().compareTo(e2.getName())).collect(Collectors.toList());
             empSortedByName.forEach(System.out::println);  
             
         //name descending order    
         List<Employee1> empSortedByNameDesceningOrder = employees.stream()
                     .sorted(Comparator.comparing(Employee1::getName).reversed()).collect(Collectors.toList());
                     empSortedByNameDesceningOrder.forEach(System.out::println);    
           System.out.println("**********************8");            
         

         List<Employee1> empSortedByName2 = employees.stream()
                     .sorted(Comparator.comparing(Employee1::getName)).collect(Collectors.toList()); //ascending order
         empSortedByName2.forEach(System.out::println);	
         
      //   find the employee name  in sorted order whose  salary is grater than 1000 in java 8 using stream api
         System.out.println("========================================================");
            List<String> sortedNames = employees.stream()
            		.filter(emp -> emp.getSalary() >= 420000)
            		//.sorted((e1, e2) -> e1.getName().compareTo(e2.getName()))
            		.map(Employee1::getName)
            		.collect(Collectors.toList());
            sortedNames.forEach(System.out::println);	

           //System.out.println("Employees with salary greater than 1000 in sorted order: " + sortedNames);
          System.out.println("==============================================");  
          
         // Sort Employee by Name and Salary in Java 8
            List<Employee1> sortedEmployees = employees.stream()
                    .sorted(Comparator.comparing(Employee1::getName)
                            .thenComparing(Employee1::getSalary))
                    .collect(Collectors.toList());

            sortedEmployees.forEach(System.out::println);     
       //Sorting in Descending Order
            System.out.println("Descending order ");
            List<Employee1> sortedEmployees1 = employees.stream()
                    .sorted(Comparator.comparing(Employee1::getName, Comparator.reverseOrder())
                            .thenComparing(Employee1::getSalary, Comparator.reverseOrder()))
                    .collect(Collectors.toList());

            sortedEmployees1.forEach(System.out::println); 
            
       //sort Employee Age
            System.out.println("Sort EMployee Age");
            List<Employee1>  empAge=employees.stream().sorted(Comparator.comparingInt(Employee1::getAge))
            		.collect(Collectors.toList());
            empAge.forEach(System.out::println);
            
            //reverse
            List<Employee1> empreverseAge=employees.stream().sorted(Comparator.comparingInt(Employee1::getAge)
            		.reversed()).collect(Collectors.toList());
            empreverseAge.forEach(System.out::println);
            
            System.out.println("--------------");
            
            
 		   //---------------
            List<Employee1> results = employees.stream()
                    .filter(b -> b.getAge() >=35 && b.getName().length() > 4)
                    .collect(Collectors.toList());
            System.out.println(results);
            List<Employee1> results2 = employees.stream()
                    .filter(b -> b.getAge() >=35)
                    .filter(b -> b.getName().length() >4)
                    .collect(Collectors.toList());
            System.out.println(results2);
 
        //Sahi Shai    
       //Group By who stay in same city with duplicate employee
            
            Map<String, List<Employee>> employeesByCity = employees.stream()
                    .collect(Collectors.groupingBy(Employee1::getCity));

            // Print employees who belong to the same city
            employeesByCity.forEach((city, employeeList) -> {
                if (employeeList.size() > 1) {
                    System.out.println("Employees in " + city + ": " + employeeList);
                }
            });
	}

}
class Employee1 {
    private int id;
    private String name;
    private int age;
    private long salary;
	
	public Employee1(int id, String name, int age, long salary) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee1 [id=" + id + ", name=" + name + ", age=" + age + ", salary=" + salary + "]";
	}
    
    
    
    
}
