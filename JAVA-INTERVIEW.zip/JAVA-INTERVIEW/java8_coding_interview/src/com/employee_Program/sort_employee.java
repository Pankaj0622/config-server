package com.employee_Program;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class sort_employee {

	public static void main(String[] args) {
		
		List<Employee> empList= new ArrayList<Employee>();
		
		empList.add(new Employee(111, "Jiya Brein", 32,"Female", "HR", 2011, 25000.0));
		empList.add(new Employee(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
		empList.add(new Employee(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
		empList.add(new Employee(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
		empList.add(new Employee(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
		
		empList.add(new Employee(122, "Paul Niksui", 25, "Male", "Sales And Marketing", 2015, 13500.0));
		empList.add(new Employee(199, "Amelia Zoe", 24, "Female", "Sales And Marketing", 2016, 11500.0));
		empList.add(new Employee(244, "Nicolus Den", 24, "Male", "Sales And Marketing", 2017, 10700.5));
		
		//Sort based On Salary
		//approach1
	
		 List<Employee> employeesSortedList1 = empList.stream()
	            .sorted((o1, o2) -> (int)(o1.getSalary()-o2.getSalary())).collect(Collectors.toList());
	     employeesSortedList1.forEach(System.out::println);
	     
	     //approach 2
	     List<Employee > employeesSortedList2 = empList.stream()
	             .sorted(Comparator.comparingDouble(Employee::getSalary)).collect(Collectors.toList());
	     //ascending order
	         System.out.println(employeesSortedList2);
	         
	      //Sort based on id and name
	         
	         List<Employee> sortedList = empList.stream()
	                 .sorted(Comparator.comparing(Employee::getName))
	                 .collect(Collectors.toList());

	             for (Employee employee : sortedList) {
	                 System.out.println(employee.getName());
     } 
           
	}
}
