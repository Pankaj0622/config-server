package com.employee_Program;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.Set;
import java.util.stream.Collectors;

public class Employee_Lab {

	public static void main(String[] args) {
		
		List<Employee> empList= new ArrayList<Employee>();
        
		empList.add(new Employee(111, "Jiya Brein", 32,"Female", "HR", 2011, 25000.0));
		empList.add(new Employee(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
		empList.add(new Employee(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
		empList.add(new Employee(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
		empList.add(new Employee(155, "Nima Roy", 27, "Female", "HR", 2013, 22700.0));
		
		empList.add(new Employee(122, "Paul Niksui", 25, "Male", "Sales And Marketing", 2015, 13500.0));
		empList.add(new Employee(199, "Amelia Zoe", 24, "Female", "Sales And Marketing", 2016, 11500.0));
		empList.add(new Employee(244, "Nicolus Den", 24, "Male", "Sales And Marketing", 2017, 10700.5));
		
		empList.add(new Employee(255, "Ali Baig", 23, "Male", "Infrastructure", 2018, 12700.0));		
		empList.add(new Employee(211, "Jasna Kaur", 27, "Female", "Infrastructure", 2014, 15700.0));
		empList.add(new Employee(133, "Martin Theron", 29, "Male", "Infrastructure", 2012, 18000.0));
		
		empList.add(new Employee(144, "Murali Gowda", 28, "Male", "Product Development", 2014, 32500.0));
		empList.add(new Employee(266, "Sanvi Pandey", 26, "Female", "Product Development", 2015, 28900.0));
		empList.add(new Employee(277, "Anuj Chettiar", 31, "Male", "Product Development", 2012, 35700.0));
		empList.add(new Employee(188, "Wang Liu", 31, "Male", "Product Development", 2015, 34500.0));
		empList.add(new Employee(222, "Nitin Joshi", 25, "Male", "Product Development", 2016, 28200.0));
		
		empList.add(new Employee(166, "Iqbal Hussain", 43, "Male", "Security And Transport", 2016, 10500.0));
		empList.add(new Employee(200, "Jaden Dough", 38, "Male", "Security And Transport", 2015, 11000.5));
		
		empList.add(new Employee(177, "Manu Sharma", 35, "Male", "Account And Finance", 2010, 27000.0));		
		empList.add(new Employee(233, "Jyothi Reddy", 27, "Female", "Account And Finance", 2013, 21300.0));
		
		
		//total salary
		Double total = empList.stream()
				   .collect(Collectors.summingDouble(Employee::getSalary));		
		System.out.println("Total Employees Salary : " + total);	
		
		  
		 //min salary		   1st Approach
		 Optional<Employee> minSalaryEmp = 
		            empList.stream()
		            .collect(Collectors.minBy(Comparator.comparing(Employee::getSalary)));	
		 System.out.println("Employee with minSalaryEmp Salary " + minSalaryEmp);	
		 
		 //2 nd Approach
		 Optional<Employee> lowestPaid = empList.stream().min((e1, e2) -> Double.compare(e1.getSalary(), e2.getSalary()));
		 lowestPaid.ifPresent(e -> System.out.println("Lowest Paid: " + e.getSalary()));
		  
		 //max salary
		 Optional<Employee> maxSalaryEmp = 
		            empList.stream()
		            .collect(Collectors.maxBy(Comparator.comparing(Employee::getSalary)));	
		 System.out.println("Employee with maximum Salary " + maxSalaryEmp);
		 System.out.println("Employee with max salary:"
		            + (maxSalaryEmp.isPresent()? maxSalaryEmp.get():"Not Applicable"));
		 
		 //2 nd Approach
		 Optional<Employee> highestPaid = empList.stream().max((e1, e2) -> Double.compare(e1.getSalary(), e2.getSalary()));
		 highestPaid.ifPresent(e -> System.out.println("Highest Paid: " + e.getSalary()));
		 

		//max salary with name
		 Employee maxSalaryEmployee = empList.stream()
	                .max((e1, e2) -> Double.compare(e1.getSalary(), e2.getSalary()))
	                .orElse(null);

	        if (maxSalaryEmployee != null) {
	            System.out.println("Employee with the maximum salary: " + maxSalaryEmployee.getName());
	        } else {
	            System.out.println("No employees found.");
	        }
		 
		 //max age  1
		 System.out.println("----_____");
		 Optional<Employee> maxAge=empList.stream().collect(Collectors.maxBy(Comparator.comparing(Employee::getAge)));
		 System.out.println("Employee with max Age:"
		            + (maxAge.isPresent()? maxAge.get():"Not Applicable"));
		 
		 //max age with name 2
		 Employee employeeWithMaxAge = empList.stream()
	                .max(Comparator.comparingInt(Employee::getAge))
	                .orElseThrow(); // orElseThrow() is used assuming the list is not empty

	        System.out.println("Employee with maximum age: " + employeeWithMaxAge.getName()
	                + ", Age: " + employeeWithMaxAge.getAge());
		 
	        //Employee Max Age
		 OptionalInt max=empList.stream().mapToInt(Employee::getAge).max();
			if(max.isPresent())
				System.out.println("Maxium age of Employee:"+max.getAsInt());
			
			 
		 
		 //average salary
		 System.out.println("Find Average Salary");
		 double avgSalary=empList.stream()
	             .mapToDouble(Employee::getSalary)
	             .average()
	             .getAsDouble(); 
	     System.out.println(avgSalary);	             
	             
		  //find department
		   empList.stream()
                  .map(Employee::getDepartment)
                  .distinct()
                  .forEach(System.out::println);
		   
		 //to find the employee list age is greater > ? and print name 
		   System.out.println("EmployeName");
		   List<String>  empfilter=empList.stream().filter(e->e.getAge()>=30)
				   .map(Employee::getName)
				   .collect(Collectors.toList());    
		   empfilter.forEach(System.out::println);
		   
		 //to find the employee list salary is greater than >2000 and print name
		   
		   List<String>  empNameSalary=empList.stream().filter(e->e.getSalary()>=32000)
				   .map(Employee::getName)
				   .collect(Collectors.toList());    
		   empNameSalary.forEach(System.out::println);	   
		   
		   
	//Count the number of employees in each department?
		   Map<String, Long> employeeCountByDepartment=
				   empList.stream().collect(Collectors.groupingBy(Employee::getDepartment, Collectors.counting()));				       
				   Set<Entry<String, Long>> entrySet = employeeCountByDepartment.entrySet();				            
				   for (Entry<String, Long> entry : entrySet)
				   {
				       System.out.println(entry.getKey()+" : "+entry.getValue());
				   }
				   
		 //How to find second highest salary
		   System.out.println("=============================================");		   
			Optional<Employee> emp = empList.stream()
			       .sorted(Comparator.comparingDouble(Employee::getSalary).reversed()).skip(1).findFirst();

		  System.out.println(emp.get());
		  
		  //Salary Based on each department
		  
		  System.out.println("============================================");
		  Map<String, Double> salaryByDepartment = empList.stream()
	                .collect(Collectors.groupingBy(Employee::getDepartment,
	                        Collectors.summingDouble(Employee::getSalary)));
	        // Print the result
	        salaryByDepartment.forEach((department, totalSalary) ->
	                System.out.println("Department: " + department + ", Total Salary: " + totalSalary)); 
	        
	       System.out.println("==============================================");
	       
	       //To find departement wise highest salary
	       
	       System.out.println("Departement wise highest salary");
	       Map<Object, Object> topEmployees = empList.stream()
	               .collect(Collectors.groupingBy(e -> e.department, 
	                       Collectors.collectingAndThen(
	                               Collectors.maxBy(Comparator.comparingDouble(e -> e.salary)), Optional::get)));                                                
	                              
          //System.out.println(topEmployees);  
	       
          topEmployees.entrySet().stream().forEach(System.out::println);
          
	      //update employee salary whose salary is less than 20000  
	      System.out.println("=========================================");	      
	      empList.stream()
          .filter(employee -> employee.getSalary() < 20000)
          .forEach(employee -> employee.setSalary(employee.getSalary() + 2000));
         // Print the updated salaries
	     empList.forEach(employee -> System.out.println(employee.getName() + ": " + employee.getSalary()));
	     
	     
	     // employee of list age > 30 and salary > 30000
		 System.out.println("=================****=============");
		 List<Employee> filteredEmployees = empList.stream()
	                .filter(employee -> employee.getAge() > 30 && employee.getSalary() > 30000)
	                .collect(Collectors.toList());

	        // Print the details of matching employees
		 filteredEmployees.forEach(System.out::println);
		 //filteredEmployees.forEach(emp->emp(System.out.println(emp)));
	    filteredEmployees.forEach(employee -> System.out.println("Name: " + employee.getName() + ", Age: " + employee.getAge() + ", Salary: " + employee.getSalary()));
	}
	

}


class Employee
{
    int id;
     
    String name;
     
    int age;
     
    String gender;
     
    String department;
     
    int yearOfJoining;
     
    double salary;

	public Employee(int id, String name, int age, String gender, String department, int yearOfJoining, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.department = department;
		this.yearOfJoining = yearOfJoining;
		this.salary = salary;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getYearOfJoining() {
		return yearOfJoining;
	}

	public void setYearOfJoining(int yearOfJoining) {
		this.yearOfJoining = yearOfJoining;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age + ", gender=" + gender + ", department="
				+ department + ", yearOfJoining=" + yearOfJoining + ", salary=" + salary + "]";
	}
    
    

}


