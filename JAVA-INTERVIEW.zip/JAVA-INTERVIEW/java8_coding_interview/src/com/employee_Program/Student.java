package com.employee_Program;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Student {
	
	private int id;
    private String name;    

	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}
	
	public static void main(String[] args) {
		
		/*Student person1 = new Student(1, "pankaj");
		Student person2 = new Student(2, "John");
		Student person3 = new Student(2, "John");

	        List<Student> personList = new ArrayList<>();
	        personList.add(person1);
	        personList.add(person2);
	        personList.add(person3);

	        List<Student> intlist = Arrays.asList( person1,person2,person3);*/
	        
	       /* Map<Integer, List<String>> grouped = intlist.stream()
	                .collect(Collectors.groupingBy(id->id). 
	                         Collectors.mapping(arr -> arr[1], Collectors.toList();
	        
	        System.out.println(grouped);*/
	        
	        //Sorting a List of Custom Objects
	        
	        List<Student> studentList = new ArrayList<>();
	        studentList.add(new Student(10,"sam"));
	        studentList.add(new Student(12,"jam"));
	        studentList.add(new Student(4,"array"));
	        studentList.add(new Student(155,"jai"));
	        studentList.add(new Student(3,"james"));
	        studentList.add(new Student(5,"sid"));
	        studentList.add(new Student(1,"prince"));
	        
	        
	        //sort Based On Id
	        List<Student> sortStudentById = studentList.stream().sorted((id1,ide2)->id1.getId()-ide2.getId()).collect(Collectors.toList());
	        sortStudentById.forEach(id->System.out.println(id));
	        
	        //sort Based On Name
	        System.out.println("---------------------------------");
	        List<Student> sortStudentByName=studentList.stream().sorted((s1,s2)->s1.getName().compareTo(s2.getName())).collect(Collectors.toList());
	        
	        sortStudentByName.forEach(name->System.out.println(name));
	        
	        
	        //Another way to do this using method reference

	        
	        List<Student> sortStudentByName1 =studentList.stream().sorted(Comparator.comparing(Student::getName)).collect(Collectors.toList());
	        
	        for(Student s:sortStudentByName1) {
	        	System.out.println("Name is :-"+s.name);
	        }
	        
	        

	        
	        
	        
	        
	    }

	
		
		
		
	}

	

