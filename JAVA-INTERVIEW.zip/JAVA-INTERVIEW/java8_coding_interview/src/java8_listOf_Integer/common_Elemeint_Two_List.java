package java8_listOf_Integer;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class common_Elemeint_Two_List {

	public static void main(String[] args) {
		List <Integer> list1 = new ArrayList<>(); 
  
		list1.add(1); 
        list1.add(4); 
        list1.add(3); 
        list1.add(2); 
      
     System.out.println("List1: "+ list1); 
    
    ArrayList<Integer> list2 = new ArrayList<>(); 
    
       list2.add(4); 
       list2.add(3); 
       list2.add(5); 
    
    System.out.println("List2: "+ list2); 

    list1.retainAll(list2); 

    System.out.println("Common elements: "+ list1); 
    
    //Using java 8
    System.out.println(list1.stream().filter(list2::contains).collect(Collectors.toList())); 
    
    
    //Remove Duplicate Value from Both list
    
    list1.addAll(list2);
    Set uniqueValues =new HashSet<>(list1);
    System.out.println("Unique Number:"+uniqueValues);
    
} 
} 
