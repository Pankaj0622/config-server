package java8_listOf_Integer;

import java.util.Arrays;
import java.util.List;

public class find_first_element_arraylist {

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(10,15,8,49,25,98,98,32,15);
		list.stream()
              .findFirst()
              .ifPresent(System.out::println);
        
        
        
	   //first number
       List<Integer> myList = Arrays.asList(10,15,8,49,25,98);
        
       Integer  firstNumber=myList.stream().findFirst().get();
       System.out.println(firstNumber);
       
       //LastNumber 
       Integer lastNumber = myList.stream().reduce((x,y) -> y).get();
       System.out.println(lastNumber);
	}

}
