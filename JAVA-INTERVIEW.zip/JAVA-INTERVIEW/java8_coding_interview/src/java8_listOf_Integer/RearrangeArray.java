package java8_listOf_Integer;

import java.util.Arrays;


public class RearrangeArray {
    public static void main(String[] args) {
        int[] numbers = {-3, 7, -1, 5, -2, 4, -6};

        int[] rearrangedArray = Arrays.stream(numbers)
                .boxed() // Convert to Integer stream
                .sorted((a, b) -> Integer.compare(Math.abs(a), Math.abs(b))) // Sort by absolute values
                .mapToInt(Integer::intValue) // Convert back to primitive int stream
                .toArray();

        int[] result = new int[rearrangedArray.length];
        int positiveIndex = 0, negativeIndex = 1;

        for (int num : rearrangedArray) {
            if (num >= 0) {
                result[positiveIndex] = num;
                positiveIndex += 2;
            } else {
                result[negativeIndex] = num;
                negativeIndex += 2;
            }
        }

        System.out.println("Rearranged Array: " + Arrays.toString(result));
    }
}
