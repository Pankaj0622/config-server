package java8_listOf_Integer;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


public class sort_arrayList {

	public static void main(String[] args) {
		List<Integer> myList = Arrays.asList(10,15,8,49,25,98,98,32,15);
		
		//Sorting in ascending order
		//Method 1
        myList.stream()
              .sorted()
              .forEach(System.out::println);
		
        //Method 2
		Comparator<Integer> comparator = new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o1 - o2;
            }
        };
        myList.sort(comparator);
        System.out.println(Arrays.toString(myList.toArray())); 
        
        //Sorting in descending order
        
        List<Integer>  sortedList=myList.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());
        System.out.println(sortedList);
        
	}

}
