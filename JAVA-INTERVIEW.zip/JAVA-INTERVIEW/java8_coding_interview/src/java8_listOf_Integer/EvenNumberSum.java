package java8_listOf_Integer;

import java.util.Arrays;
import java.util.List;

public class EvenNumberSum {

	public static void main(String[] args) {
		List<Integer> myList = Arrays.asList(10,15,8,49,25,98,98,32,15);
		int sumOfEvenNumbers = myList.stream()
                .filter(n -> n % 2 == 0)  // Filter even numbers
                .mapToInt(Integer::intValue)  // Convert to primitive int stream
                .sum();  // Sum the filtered numbers

        System.out.println("Sum of even numbers: " + sumOfEvenNumbers);
	}

}
