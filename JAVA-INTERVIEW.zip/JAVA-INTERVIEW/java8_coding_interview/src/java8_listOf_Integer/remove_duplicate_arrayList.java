package java8_listOf_Integer;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class remove_duplicate_arrayList {

	public static void main(String[] args) {
		List<Integer> integerList = Arrays.asList(1,2,3,4,1,2,3);
        System.out.println("After removing duplicates : ");
        //1
        integerList.stream().collect(Collectors.toSet()).forEach(System.out::print);
        
        //2
        integerList.stream()
        .distinct().collect(Collectors.toList())
        .forEach(System.out::print);
	}

}
