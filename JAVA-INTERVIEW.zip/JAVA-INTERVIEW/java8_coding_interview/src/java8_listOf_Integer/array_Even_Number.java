package java8_listOf_Integer;

import java.util.Arrays;
import java.util.stream.IntStream;

public class array_Even_Number {

	public static void main(String[] args) {
		int[] array=new int[] {1,2,3,4,5};
		
		int[] evenArray=Arrays.stream(array)
				.filter(a->a%2==0).toArray();
        System.out.println(Arrays.toString(evenArray));

	}

}
