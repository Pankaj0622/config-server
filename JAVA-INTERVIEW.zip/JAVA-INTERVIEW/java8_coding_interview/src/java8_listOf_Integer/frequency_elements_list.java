package java8_listOf_Integer;

import java.util.Arrays;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class frequency_elements_list {

	public static void main(String[] args) {
		//List<String> list = Arrays.asList("B", "A", "A", "C", "B", "A");
        /*Set<String> distinct = new HashSet<>(list);
        for (String s: distinct) {
            System.out.println(s + ": " + Collections.frequency(list, s));
        }*/
		
		List<Integer> list1=Arrays.asList(1,2,3,4,1,3,5,8); 
		Set<Integer> setint = new HashSet<>(list1);
        for (Integer s: setint) {
            System.out.println(s + ": " + Collections.frequency(list1, s));
	    
        }
        
        List<Integer> listInteger = Arrays.asList(9, 2, 2, 7, 6, 6, 5, 7);        
        Map<Integer, Integer> map=listInteger.stream()
        		.collect(Collectors.toMap(Function.identity(),value->1,Integer::sum));
        
        System.out.println(map);
        
        System.out.println("next appraoch ");
        
        //For Duplicate frequency
        List<Integer> myList = Arrays.asList(9, 2, 2, 7, 6, 6, 5, 7);
        myList.stream()
        // Creates a map {4:1, 5:2, 7:2, 8:2, 9:1}
        .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
        .entrySet()
        // Convert back to stream to filter
        .stream()
        .filter(element -> element.getValue() > 1)
        // Collect elements to List and print out the values
        .collect(Collectors.toList())
        .forEach(System.out::println);
        
        List<Integer> myList2 = Arrays.asList(9, 2, 2, 7, 6, 6, 5, 7);
        myList2.stream()
        .filter(i -> Collections.frequency(myList2, i) > 1)
        //Collect elements to a Set and print out the values 
        .collect(Collectors.toSet())
        .forEach(System.out::println);

}
}