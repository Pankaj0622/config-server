package java8_ArrayProgram;

import java.util.Arrays;

import java.util.List;
import java.util.stream.Collectors;

public class sorted_Integer_numbers {

	public static void main(String[] args) {
		List<Integer> sortedNumbers = Arrays.asList(3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5);
		
		List<Integer>  list=sortedNumbers.stream().sorted().collect(Collectors.toList());
		
		System.out.println(list);
  
        int[] numbers = {1, 2, 3, 2, 4, 5, 3, 6};
        
        int[] sortNum=Arrays.stream(numbers).sorted().toArray();
      

        System.out.println(Arrays.toString(sortNum)); 

	}

}
