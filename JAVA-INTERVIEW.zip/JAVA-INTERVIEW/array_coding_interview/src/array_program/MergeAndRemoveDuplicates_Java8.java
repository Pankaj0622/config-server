package array_program;
import java.util.Arrays;
import java.util.stream.IntStream;

public class MergeAndRemoveDuplicates_Java8 {
	
	    public static void main(String[] args) {
	        int[] array1 = {5, 3, 7, 1, 8};
	        int[] array2 = {9, 3, 2, 5, 6};

	        // Sorting, merging, and removing duplicates using Stream API
	        int[] resultArray = mergeSortAndRemoveDuplicates(array1, array2);

	        // Displaying the result
	        System.out.println("Sorted and Merged Array with Duplicates Removed:\n " + Arrays.toString(resultArray));
	    }

	    private static int[] mergeSortAndRemoveDuplicates(int[] array1, int[] array2) {
	        // Merge, sort, and remove duplicates using the Stream API
	        return IntStream.concat(Arrays.stream(array1), Arrays.stream(array2))
	                .distinct()
	                .sorted()
	                .toArray();
	    }
	}
