package array_program;
import java.util.Arrays;
public class findtripletNumber {
	   
	
	    static int count_Triplets(int[] A, int N){
	     int count = 0;
	     Arrays.sort(A);
	     for(int i = 0; i < N; i++){  // for first number
	       for(int j = i + 1; j < N; j++){  // for second number
	          for(int k = j + 1; k < N; k++){  // for third number
	              if(A[i] + A[j] == A[k]){
	                    count++; // increment count
	              }
	          }
	       }
	     }
	     return count; 
	   }
	 
		public static void main(String args[]) {
			// Your code goes here
			int[] A = { 5 ,7 ,12 ,3 ,2 };
			int N = 5;
			System.out.print(count_Triplets(A, N));
		}
	}
