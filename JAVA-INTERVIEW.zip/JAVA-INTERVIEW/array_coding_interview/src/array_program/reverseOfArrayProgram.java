package array_program;

public class reverseOfArrayProgram {

	public static void main(String[] args) {
		int[] arr = {1, 7, 8, 9};
		int start = 0;
        int end = arr.length - 1;
    
       //Run a loop while start is less than end
        while(start < end) {

            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;

            start++;
            end--;
	}
        for(int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }

}
}
