package array_program;

public class sortArray {

	public static void main(String[] args) {
		int arr[] = new int[] { 12, 44, 23, 56, 25, 78, 13 };
		int temp;
		for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]>arr[j]) {
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		System.out.println("Array in Sorting Number");
			for(int i=0;i<arr.length;i++) {
				System.out.println(arr[i]+" ");
			}
		}
		

	}


