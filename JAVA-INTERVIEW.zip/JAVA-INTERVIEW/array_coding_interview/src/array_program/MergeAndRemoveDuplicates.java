package array_program;

import java.util.Arrays;

public class MergeAndRemoveDuplicates {

    public static void main(String[] args) {
        int[] array1 = {5, 3, 7, 1, 8,8};
        int[] array2 = {9, 3, 2, 5, 6,7};
        
        // Sorting and merging the arrays
        int[] mergedArray = mergeAndSortArrays(array1, array2);

        // Removing duplicates from the sorted array
        int[] resultArray = removeDuplicates(mergedArray);

        // Displaying the result
        System.out.println("Sorted and Merged Array with Duplicates Removed: " + Arrays.toString(resultArray));
    }

    private static int[] mergeAndSortArrays(int[] array1, int[] array2) {
        int[] mergedArray = new int[array1.length + array2.length];
        System.arraycopy(array1, 0, mergedArray, 0, array1.length);
        System.arraycopy(array2, 0, mergedArray, array1.length, array2.length);

        Arrays.sort(mergedArray);
        return mergedArray;
    }

    private static int[] removeDuplicates(int[] sortedArray) {
        int length = sortedArray.length;

        // Check for empty or single-element array
        if (length <= 1) {
            return sortedArray;
        }

        int index = 0;

        // Iterate through the sorted array
        for (int i = 1; i < length; i++) {
            // If the current element is different from the previous one, copy it to the next position
            if (sortedArray[i] != sortedArray[index]) {
                index++;
                sortedArray[index] = sortedArray[i];
            }
        }
        // Create a new array with the unique elements
        int[] resultArray = Arrays.copyOf(sortedArray, index + 1);
        return resultArray;
        
        // Using java 8
        
        
    }
}
