package array_program;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Max_Min_Value_Array {

	public static void main(String[] args) {
     int arr[] = {12,45,34,66,78,90};
     
     /*int smallest=arr[0];
     int largest=arr[0];
     
     for(int i=0;i<arr.length;i++) {
    	 if(arr[i]>largest) {
    	    largest=arr[i];
    	 }else if
    	  (arr[i] <smallest) {
    		 smallest=arr[i];
    	 }
     }     
     System.out.println("Largest Numbers :"+largest);
     System.out.println("Smallest Numbers:"+smallest);*/
     
     System.out.println("---Using Java 8");
     
     //1 Aproach
     Integer[] A = { 6, 8, 3, 5, 1, 9 };     
     List<Integer> ints = Arrays.asList(A);
     System.out.println("Min element is " + Collections.min(ints));
     System.out.println("Max element is " + Collections.max(ints));
     
  // primitive integer array
     //2 Approach
     
     int[] arrayNumber = { 6, 8, 3, 5, 1, 9 };
     List<Integer> myArray = Arrays.stream(arrayNumber)
                             .boxed()
                             .collect(Collectors.toList());
     System.out.println("Min element is " + Collections.min(ints));
     System.out.println("Max element is " + Collections.max(ints));
	}

}
