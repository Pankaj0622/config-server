package array_program;

import java.util.Arrays;
import java.util.stream.IntStream;

public class secondLargest_number_in_array {

	public static void main(String[] args) {
		int myArr[]= {14,46,47,86,92};		
		
		/*int largest=myArr[0];
		
		int secondLargest=myArr[0];
		
		for(int i=0;i<myArr.length;i++) {
			if(myArr[i]>largest) {
				secondLargest=largest;
				largest=myArr[i];
			} else if (myArr[i] > secondLargest) {
		        secondLargest = myArr[i];
		        
		      }
		    }		 */
		   // System.out.println("\nSecond largest number is:" + secondLargest);
		
		
		    
		   IntStream stream =Arrays.stream(myArr);
		   int secondLargest=stream.sorted()
				         .skip(myArr.length-2)
				         .findFirst()
				         .getAsInt();
		   
		   System.out.println("Second Largest Number is :"+secondLargest);
	   }

}
