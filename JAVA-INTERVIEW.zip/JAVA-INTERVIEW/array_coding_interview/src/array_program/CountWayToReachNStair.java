package array_program;

public class CountWayToReachNStair {
	 static int countWays(int n) {
	        // declaring  two variables to store the count
	        int prev = 1;
	        int prev2 = 1;
	        // Running for loop to count all possible ways
	        for (int i = 2; i <= n; i++) {
	            int curr = prev + prev2;
	            prev2 = prev;
	            prev = curr;
	        }
	        return prev;
	    }
	public static void main(String[] args) {
		 int n = 5;
	        System.out.println("Number of Ways : "+ countWays(n));
	}
}
