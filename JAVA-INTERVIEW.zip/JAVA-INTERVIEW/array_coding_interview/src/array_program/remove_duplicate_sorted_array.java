package array_program;

import java.util.Arrays;
import java.util.HashSet;

public class remove_duplicate_sorted_array {
	public static int[] removeDuplicatesAndSort(int[] arr) {
        // Step 1: Create a HashSet to store unique elements
        HashSet<Integer> uniqueElements = new HashSet<>();

        // Step 2: Traverse the input array, adding each element to the HashSet
        for (int num : arr) {
            uniqueElements.add(num);
        }

        // Step 3: Create a new array and copy elements from the HashSet
        int[] sortedArray = new int[uniqueElements.size()];
        int index = 0;
        for (int num : uniqueElements) {
            sortedArray[index++] = num;
        }

        // Step 4: Sort the new array
        Arrays.sort(sortedArray);

        return sortedArray;
    }
	public static void main(String[] args) {
		
		int[] unsortedArray = {5, 2, 8, 3, 1, 2, 3, 5, 8, 9, 9, 4};
        int[] sortedArray = removeDuplicatesAndSort(unsortedArray);

        // Step 5: Print the sorted array
        System.out.println("Sorted Array after removing duplicates:");
        for (int num : sortedArray) {
            System.out.print(num + " ");
        }
    }

	}


