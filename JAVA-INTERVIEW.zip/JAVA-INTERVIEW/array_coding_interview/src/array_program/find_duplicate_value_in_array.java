package array_program;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class find_duplicate_value_in_array {

	public static void main(String[] args) {

		int arr[]= {1, 2, 5, 5, 6, 6, 7, 2};
		
		//1 Approach
		
		/*for(int i=0;i<arr.length;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]==arr[j]) {
                  System.out.println("Duplicate Element : "+arr[j]);

				}
			}
		}*/
		
		//2 Approach
		
		List<Integer> numbers = Arrays.asList(new Integer[]{1,2,1,3,4,4});
		numbers.stream().filter(i -> Collections.frequency(numbers, i) >1)
        .collect(Collectors.toSet()).forEach(System.out::println);
		
		
        //3 Approach
         List<Integer> listofIntegers=Arrays.stream(arr)
                       .boxed()
                       .collect(Collectors.toList());


        listofIntegers.stream()
                      .filter(x->Collections.frequency(listofIntegers,x)>1)
                      .distinct()
                      .forEach(System.out::println);

	}

}
