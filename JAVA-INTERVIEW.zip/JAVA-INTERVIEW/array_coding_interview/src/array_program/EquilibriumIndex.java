package array_program;

public class EquilibriumIndex {
	public static int findEquilibriumIndex(int[] arr) {
        int totalSum = 0;
        int leftSum = 0;

        // Calculate the total sum of the array
        for (int num : arr) {
            totalSum += num;
        }

        for (int i = 0; i < arr.length; i++) {
            // Adjust totalSum by subtracting the current element
            totalSum -= arr[i];

            if (leftSum == totalSum) {
                return i;
            }

            // Update the leftSum for the next iteration
            leftSum += arr[i];
        }

        return -1; // No equilibrium index found
    }
	
	
	

	public static void main(String[] args) {
		int[] A = {-7, 1, 5, 2, -4, 3, 0};
        int equilibriumIndex = findEquilibriumIndex(A);

        if (equilibriumIndex != -1) {
            System.out.println("Equilibrium index is: " + equilibriumIndex);
        } else {
            System.out.println("No equilibrium index found.");
        }
    }


	}

