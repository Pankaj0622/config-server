package array_program;

public class reverse_array {
	
	public static void main(String[] args) {
		int arr[]= {4,5,2,1,8};
		
		for(int i=arr.length-1;i>=0;i--) {
			System.out.println("Reverse Array:"+arr[i]);
		}
	}

}
