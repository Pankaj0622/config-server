package array_program;

import java.util.Arrays;

public class tripletDisplay {
	
    public static void main(String[] args)
    {
        int[] nums = { 2, 7, 4, 0, 9, 5, 1, 3 };
        int target = 6;
        
        
        for(int i=0;i<nums.length-1;i++) {
        	
        	for(int j=i;j<nums.length;j++) {
        		
        		for(int k=j;k<nums.length;k++) {
        			
        		if(nums[i]+nums[j]+nums[k]==target)
        			
        			System.out.println(nums[i]+"\t"+nums[j]+"\t"+nums[k]);
        			
        		}
        	}
        }
 
        
}
}
