package array_program;

public class leaders_arrayProgram {

	/*void printLeaders(int arr[], int size)
    {
        for (int i = 0; i < size; i++)
        {
            int j;
            for (j = i + 1; j < size; j++)
            {
                if (arr[i] <=arr[j])
                    break;
            }
            if (j == size) // the loop didn't break
                System.out.print(arr[i] + " ");
        }
    }*/
	public static void main(String[] args) {
		
		
		/*leaders_arrayProgram lead = new leaders_arrayProgram();
        int arr[] = new int[]{16, 17, 4, 3, 5, 2};
        int n = arr.length;
        lead.printLeaders(arr, n);
        */
        
		 //Declare and initialize the array elements
	      int array[] = {16, 17, 4, 3, 5, 6, 9, 1, 8, 2};
	      int size = array.length;
	      System.out.println("Leaders in the array are: ");

	      //Logic Implementtaion
	      for (int i = 0; i < size; i++){
	         int j;
	         for (j = i + 1; j < size; j++){
	            if (array[i] <=array[j])
	               break;
	         }
	         if (j == size) // the loop didn't break{
	         
	            //print the result
	            System.out.print(array[i] + " ");
	         }
	      }
	   }