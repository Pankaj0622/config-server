package array_program;

import java.util.Arrays;

public class compArray {

	public static void main(String[] args) {
		int num1[] = {4,5,3,2,1};
		int num2[] = {3,7,8,2,6};
		int num3[] = {4,5,3,2,1};
		
		//System.out.println(Arrays.equals(num1,num2));   True
		//System.out.println(Arrays.equals(num1,num3));   false

		

	}

}
