package array_program;

public class Count_1_Without_Built {

	public static void main(String[] args) {
        int[] arr = new int[]{1, 1, 0, 1, 0, 1, 1, 0};
        int sum=0;
        for(int i:arr) {
        	sum=sum+i;
        }
        System.out.println("count of 1's::" + sum);
        System.out.println(arr.length);  //8-5=3
        System.out.println("count of 0's::" + (arr.length - sum));
	}

}
