package array_program;

public class first_last_element_array {

	public static void main(String[] args) {
		
		 int a[]=new int[]{1,2,3,4,5};
		
		 int size=a.length;
		 System.out.println("First element of an array is"+a[0]);
		 System.out.println("Last element of an array is "+a[size-1]);
		 }
		 }
	
