package com.jlcindia.com;

public class lab1 {

	public static void main(String[] args) {

		  //lab1 lhs=new lab1();
		  //System.out.println(lhs.printHello());
		  
		  System.out.println(lab1.printHello());
		  
	}



private static String printHello() {
	return "Hello";
}
}