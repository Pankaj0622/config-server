package com.jlcindia.com;

public class test_static {

	public static void main(String[] args) {
		Hello h=new Hello();
		 h.show();
		 

	}


class Hello{
	int a=10;
	static int b=20;
	//void show() {
		/*String a="jlc";
		String b="Sd";
		System.out.println(a);
		System.out.println(b);*/
		System.out.println(this.a);
		System.out.println(this.b);
	//}
}}