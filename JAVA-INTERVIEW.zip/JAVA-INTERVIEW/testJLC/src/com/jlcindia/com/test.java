package com.jlcindia.com;

public class test {
	
	static int add(int a,int b){
		return a+b;
		}  
	static int add(int aa,int bb){
		return a+b;}  

	public static void main(String[] args) {

	}

}
