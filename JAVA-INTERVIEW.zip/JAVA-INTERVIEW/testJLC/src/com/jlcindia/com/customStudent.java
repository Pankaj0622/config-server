package com.jlcindia.com;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class customStudent {
	 List<Student> studlist1 = new ArrayList<Student>();

	    /**
	     * @param args the command line arguments
	     */
	    public static void main(String[] args) {

	        List<Student> studlist = new ArrayList<Student>();
	        studlist.add(new Student("1", "John", "New York"));
	        studlist.add(new Student("1", "Max", "California"));
	        studlist.add(new Student("2", "Andrew", "Los Angeles"));
	        studlist.add(new Student("3", "Michael", "New York"));
	        studlist.add(new Student("3", "Sam", "California"));
	        studlist.add(new Student("4", "Mark", "New York"));

	        //Map<String, List<Student>> groupedStudents = new HashMap<String, List<Student>>();
	        
	        Map<String, List<Student>> groupedStudents=studlist.stream().collect(Collectors.groupingBy(Student::getStud_id));
	        
	        System.out.println("Final List:"+groupedStudents);
	        
	       /* for (Student student: studlist) {
	            String key = student.stud_id;
	            if (groupedStudents.containsKey(key)) {
	                List<Student> list = groupedStudents.get(key);
	                list.add(student);
	                }
	            else {
	            List<Student> list = new ArrayList<Student>();
	            list.add(student);
	            groupedStudents.put(key, list);}  
	            
	           
	        }*/

	      //  System.out.println(groupedStudents);
	      /*  Set<String> groupedStudentsKeySet = groupedStudents.keySet();
	        int index = 0;
	        for (String id: groupedStudentsKeySet) {
	            List<Student> stdnts = groupedStudents.get(id);

	            for (Student student : stdnts) {
	            	System.out.println(student);*/
//	               Want to create a new arraylist as belows.Grouing data in arraylist according to same ID
//	                 arraylist will be as
	//
//	                 index 0: 1,John,New York,Max,Califoornia
//	                 index 1: 2, Andrew, Los Angeles
//	                 index 2: 3,Michael, New York, "Sam", California
//	                 index 3: 4,Mark, New York


	            }

	        

	    }
	

class Student {
    String stud_id;
    String stud_name;
    String stud_location;

    Student(String sid, String sname, String slocation) {

        this.stud_id = sid;
        this.stud_name = sname;
        this.stud_location = slocation;

    }

	public String getStud_id() {
		return stud_id;
	}

	public void setStud_id(String stud_id) {
		this.stud_id = stud_id;
	}

	public String getStud_name() {
		return stud_name;
	}

	public void setStud_name(String stud_name) {
		this.stud_name = stud_name;
	}

	public String getStud_location() {
		return stud_location;
	}

	public void setStud_location(String stud_location) {
		this.stud_location = stud_location;
	}

	@Override
	public String toString() {
		return "Student [stud_id=" + stud_id + ", stud_name=" + stud_name + ", stud_location=" + stud_location + "]";
	}
    
    
}