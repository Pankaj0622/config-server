package com.string_lab;

public class occurance_of_word {

	public static void main(String[] args) {
		String str="welcome to JLC ,Java is training center,Java training placement ,Java is popular language";
		
		//int length=str.length();
		int count=0;
		for(int i=0;i<str.length();i++) {
			int index=str.indexOf("Java",i);
			if(index>=0) {
				i=index;
			    count++;
			}
		}
		System.out.println("Count:"+count);

	}

}
