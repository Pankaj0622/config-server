package com.string_lab;

public class occurnace_char_string {

	public static void main(String[] args) {
		String s="Java is java again java";
		char c='a';
		
		int count=s.length()-s.replace("a","").length();
		
		System.out.println("Number of occurance of 'a' in "+s+"="+count);

	}

}
