package com.string_lab;

import java.util.Scanner;

public class reverse_of_string {

	public static void main(String[] args) {
		String str,reverse=" ";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string");
		str=sc.nextLine();
		int length=str.length();
		for(int i=length-1;i>=0;i--)
			reverse=reverse+str.charAt(i);
		System.out.println("Reverse of string:"+reverse);

	}

}
