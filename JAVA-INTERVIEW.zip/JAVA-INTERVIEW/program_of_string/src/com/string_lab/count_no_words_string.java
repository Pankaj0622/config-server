package com.string_lab;

import java.util.Scanner;

public class count_no_words_string {

	public static void main(String[] args) {
	 
     /*Scanner sc=new Scanner(System.in);
     System.out.println("Enter a string");
     String str=sc.nextLine();
     String[] word=str.split(" ");
     System.out.println(word.length);*/
		
	 Scanner sc=new Scanner(System.in);	
	 System.out.println("Enter a string");
	 String str=sc.nextLine();
	 int count=0;
	 for(int i=0;i<str.length()-1;i++) {
		 if(str.charAt(i)==' ' &&(str.charAt(i+1) !=' ')) {
			 count++;
		 }
	 }
	 System.out.println("Number of words in a string="+count);
     
     
     
	}

}
