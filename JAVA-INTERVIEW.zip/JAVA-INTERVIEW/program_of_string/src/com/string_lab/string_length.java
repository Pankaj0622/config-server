package com.string_lab;

public class string_length {
	
	public static void main(String[] args) {
		String str="pankaj";
		System.out.println(str.length());
		
	}

}
