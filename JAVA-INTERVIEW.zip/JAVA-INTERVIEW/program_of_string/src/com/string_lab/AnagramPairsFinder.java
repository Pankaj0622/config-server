package com.string_lab;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AnagramPairsFinder {
	 public static boolean areAnagrams(String str1, String str2) {
	        char[] charArray1 = str1.toCharArray();
	        char[] charArray2 = str2.toCharArray();

	        Arrays.sort(charArray1);
	        Arrays.sort(charArray2);

	        return Arrays.equals(charArray1, charArray2);
	    }

	    public static List<List<String>> findAnagramPairs(String[] arr) {
	        List<List<String>> anagramPairs = new ArrayList<>();
	        Map<String, List<String>> anagramMap = new HashMap<>();
	        
	        for (String str : arr) {
	            String sortedStr = sortString(str);

	            if (anagramMap.containsKey(sortedStr)) {
	                anagramMap.get(sortedStr).add(str);
	            } else {
	                List<String> list = new ArrayList<>();
	                list.add(str);
	                anagramMap.put(sortedStr, list);
	            }
	        }

	        for (List<String> list : anagramMap.values()) {
	            if (list.size() > 1) {
	                anagramPairs.add(list);
	            }
	        }

	        return anagramPairs;
	    }

	    private static String sortString(String str) {
	        char[] charArray = str.toCharArray();
	        Arrays.sort(charArray);
	        return new String(charArray);
	    }

	public static void main(String[] args) {

		 String[] arr = {"geeksquiz", "geeksforgeeks", "abcd", "forgeeksgeeks", "zuiqkeegs"};
	        List<List<String>> output = findAnagramPairs(arr);
	        System.out.println(output);
	    }
	}